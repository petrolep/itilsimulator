<?php

namespace Doctrine\Tests;

/**
 * Base testcase class for all dbal testcases.
 */
class DbalTestCase extends DoctrineTestCase
{
}