<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures\Annotation;

/**
 * @Annotation
 * @Target("PROPERTY")
 */
final class Version
{
}
