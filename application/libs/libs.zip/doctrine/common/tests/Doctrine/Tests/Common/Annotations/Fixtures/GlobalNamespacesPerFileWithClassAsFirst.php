<?php

namespace {
	use Doctrine\Tests\Common\Annotations\Fixtures\Annotation\Secure;
	use Doctrine\Tests\Common\Annotations\Fixtures\Annotation\Route;

	class GlobalNamespacesPerFileWithClassAsFirst {}
}

namespace {
	use Doctrine\Tests\Common\Annotations\Fixtures\Annotation\Template;
}